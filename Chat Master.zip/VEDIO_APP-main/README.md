# zoom-clone-2.0

## Features
- Inro page (Host a meeting or join a meeting page)
- Name Feature(You can see names of participants)
- Video and Voice chat
- Live chat
- Invite Participants
- close/Open Video
- Mute/UnMute Audio

![Login page](https://raw.githubusercontent.com/prankas/VEDIO_APP/main/image.png)

![Live](https://raw.githubusercontent.com/prankas/VEDIO_APP/main/mq.png)
## Test 
- Windows

## How to run
- git clone
- cd zoom-clone-2.0
- npm server.js
- Go to LocalHost:3030
